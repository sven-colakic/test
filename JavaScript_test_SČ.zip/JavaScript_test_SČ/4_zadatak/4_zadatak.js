const element = ["Nesto","Nez","3","5","Ne znam","Auto","6"];
element.unshift("Truba")
console.log(element)
var x=element.pop();
console.log(x)