function Kvadrat(a) {
    this.a = a;
    this.opseg = function () {
        return this.a*4;
    }
    this.povrsina = function () {
        return this.a*this.a;
    }
}
var kvadrat = new Kvadrat(5);
console.log(kvadrat.opseg());
console.log(kvadrat.povrsina());