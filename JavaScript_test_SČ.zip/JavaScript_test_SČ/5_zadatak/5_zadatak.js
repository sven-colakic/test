function macka(visina, duzina, tezina, cijena) {
    this.visina = visina;
    this.duzina = duzina;
    this.tezina = tezina;
    this.cijena = cijena;
}
var macketina = new macka("30 cm", "40 cm", "3 kg", "poklanja se");
for (var x in macketina){
    console.log(macketina[x])
}