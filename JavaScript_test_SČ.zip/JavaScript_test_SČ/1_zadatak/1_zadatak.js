function moja_funkcija(){
    alert("Mislim da je ovo samo početak!")
}
